package com.nynaromanoff.payment_service.repository;

import com.nynaromanoff.payment_service.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, UUID> {
    Optional<Payment> findByOrderId(UUID id);
    Optional<Payment> findByPaymentIntentId(String paymentIntentId);
}
